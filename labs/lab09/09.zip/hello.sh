#!/bin/bash
HELLO=Hello
function hello
{
local HELLO=World
local HELLO=World
local HELLO=World
local HELLO=World
local HELLO=World
local HELLO=World
local HELLO=World
local HELLO=World
echo $HELLO
}
echo $HELLO
hello
local HELLO=World
local HELLO=World
local HELLO=World
local HELLO=World
echo $HELLO
}
echo $HELLO
hello
